App.onJoinPlayer.Add(function(player){
    App.showCenterLabel("산송재판!")
})